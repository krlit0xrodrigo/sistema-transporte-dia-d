import { redirect } from "next/navigation";
import { crearClienteServidor } from "@/lib/supabase/server";
import { Boton, Campo, Card, claseInput } from "@/components/ui";

export default async function Login({
  searchParams,
}: { searchParams: Promise<{ error?: string; volver?: string }> }) {
  const sp = await searchParams;

  async function entrar(formData: FormData) {
    "use server";
    const supabase = await crearClienteServidor();
    const { error } = await supabase.auth.signInWithPassword({
      email: String(formData.get("email") ?? ""),
      password: String(formData.get("password") ?? ""),
    });
    // No se distingue "usuario inexistente" de "contraseña incorrecta":
    // hacerlo permite enumerar cuentas.
    if (error) redirect("/login?error=1");
    redirect(String(formData.get("volver") || "/"));
  }

  return (
    <main className="flex min-h-screen items-center justify-center px-4">
      <Card className="w-full max-w-sm p-6">
        <h1 className="text-lg font-semibold">Logística Día D</h1>
        <p className="mt-1 text-sm text-slate-500">Villa Hayes · 4 de octubre de 2026</p>

        <form action={entrar} className="mt-6 space-y-4">
          <input type="hidden" name="volver" value={sp.volver ?? "/"} />
          <Campo etiqueta="Correo" nombre="email" requerido>
            <input id="email" name="email" type="email" required autoComplete="email" className={claseInput} />
          </Campo>
          <Campo etiqueta="Contraseña" nombre="password" requerido>
            <input id="password" name="password" type="password" required autoComplete="current-password" className={claseInput} />
          </Campo>
          {sp.error && (
            <p className="text-sm text-rose-600">Correo o contraseña incorrectos.</p>
          )}
          <Boton type="submit">Entrar</Boton>
        </form>
      </Card>
    </main>
  );
}
