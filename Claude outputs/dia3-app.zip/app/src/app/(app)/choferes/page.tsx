import Link from "next/link";
import { crearClienteServidor } from "@/lib/supabase/server";
import { Badge, Card, CardHeader, Vacio, claseInput } from "@/components/ui";
import { formatearCI, formatearTelefono } from "@/lib/format";
import type { FichaChofer } from "@/types/database";

const TONO_IDENTIDAD = {
  verificada: "ok",
  fuera_de_padron: "alerta",
  discrepancia_nombre: "error",
} as const;

export default async function Choferes({
  searchParams,
}: { searchParams: Promise<{ q?: string }> }) {
  const { q } = await searchParams;
  const busqueda = (q ?? "").trim();
  const supabase = await crearClienteServidor();

  let consulta = supabase.from("v_choferes_ficha").select("*").limit(100);

  if (busqueda) {
    // Sólo dígitos → es una cédula. Si no, búsqueda difusa por nombre:
    // los nombres del maestro vienen sucios y una coincidencia exacta
    // no encuentra casi nada.
    const soloDigitos = /^[0-9.]+$/.test(busqueda);
    consulta = soloDigitos
      ? consulta.eq("ci", busqueda.replace(/\D/g, ""))
      : consulta.ilike("nombre_completo", `%${busqueda}%`);
  }

  const { data, error } = await consulta.order("nombre_completo");
  const filas = (data ?? []) as FichaChofer[];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-semibold">Choferes</h1>
          <p className="text-sm text-slate-500">Buscá por cédula o por nombre</p>
        </div>
        <Link href="/choferes/nuevo"
          className="rounded-md bg-slate-900 px-3 py-2 text-sm font-medium text-white hover:bg-slate-700">
          Dar de alta
        </Link>
      </div>

      <form className="flex gap-2">
        <input name="q" defaultValue={busqueda} placeholder="4349952 o Daniel Britez"
               className={claseInput} autoComplete="off" />
        <button className="rounded-md bg-slate-900 px-4 text-sm font-medium text-white">Buscar</button>
      </form>

      <Card>
        <CardHeader titulo={busqueda ? `Resultados para "${busqueda}"` : "Todos los choferes"}
                    extra={<span className="text-xs text-slate-500">{filas.length} {filas.length === 100 ? "(máx.)" : ""}</span>} />
        {error ? (
          <Vacio mensaje={`No se pudo consultar: ${error.message}`} />
        ) : filas.length === 0 ? (
          <Vacio mensaje={busqueda ? "Ningún chofer coincide." : "Todavía no hay choferes cargados."} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
                <tr>
                  <th className="px-4 py-2 font-medium">Cédula</th>
                  <th className="px-4 py-2 font-medium">Nombre</th>
                  <th className="px-4 py-2 font-medium">Candidato</th>
                  <th className="px-4 py-2 font-medium">Barrio</th>
                  <th className="px-4 py-2 font-medium">Teléfono</th>
                  <th className="px-4 py-2 font-medium">Identidad</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filas.map((c) => (
                  <tr key={c.chofer_id} className="hover:bg-slate-50">
                    <td className="px-4 py-2 tabular-nums">
                      <Link href={`/choferes/${c.chofer_id}`} className="font-medium underline underline-offset-4">
                        {formatearCI(c.ci)}
                      </Link>
                    </td>
                    <td className="px-4 py-2">
                      {c.nombre_completo}
                      {c.apariciones > 1 && (
                        <span className="ml-2 text-xs text-amber-700">· {c.apariciones} apariciones</span>
                      )}
                    </td>
                    <td className="px-4 py-2 text-slate-600">{c.candidato ?? "—"}</td>
                    <td className="px-4 py-2 text-slate-600">{c.barrio ?? "—"}</td>
                    <td className="px-4 py-2 tabular-nums text-slate-600">{formatearTelefono(c.telefono_e164)}</td>
                    <td className="px-4 py-2">
                      <Badge tono={TONO_IDENTIDAD[c.estado_identidad] ?? "neutro"}>
                        {c.estado_identidad === "verificada" ? "Verificada"
                          : c.estado_identidad === "fuera_de_padron" ? "Fuera de padrón"
                          : "Nombre no coincide"}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
