import Link from "next/link";
import { notFound } from "next/navigation";
import { crearClienteServidor } from "@/lib/supabase/server";
import { Badge, Card, CardHeader, Dato, Vacio } from "@/components/ui";
import {
  ETIQUETA_ACTIVIDAD, ETIQUETA_IDENTIDAD,
  formatearCI, formatearKm, formatearTelefono,
} from "@/lib/format";
import type { Aparicion, Antecedente, FichaChofer, ResultadoPadron } from "@/types/database";

function Marca({ valor, si, no }: { valor: boolean | null; si: string; no: string }) {
  if (valor === null || valor === undefined) return <Badge tono="neutro">Sin registro</Badge>;
  return <Badge tono={valor ? "ok" : "alerta"}>{valor ? si : no}</Badge>;
}

export default async function Ficha({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await crearClienteServidor();

  const { data: ficha } = await supabase
    .from("v_choferes_ficha").select("*").eq("chofer_id", id).maybeSingle();
  if (!ficha) notFound();
  const c = ficha as FichaChofer;

  // El padrón se consulta por RPC: deja rastro en accesos_sensibles.
  const [{ data: padronRaw }, { data: apariciones }, { data: antecedentes }] = await Promise.all([
    supabase.rpc("fn_verificar_padron", { p_ci: c.ci }),
    supabase.from("apariciones_origen")
      .select("numero_fila, hoja, nombre_texto, candidato_texto, barrio_texto, fue_aplicada")
      .eq("persona_id", c.persona_id).order("numero_fila"),
    supabase.from("antecedentes")
      .select("resultado, km_recorridos, tuvo_gps, confiabilidad_dato, fuente, eleccion_id")
      .eq("persona_id", c.persona_id),
  ]);

  const padron = (Array.isArray(padronRaw) ? padronRaw[0] : padronRaw) as ResultadoPadron | undefined;
  const aps = (apariciones ?? []) as Aparicion[];
  const ants = (antecedentes ?? []) as Antecedente[];

  return (
    <div className="space-y-6">
      <div>
        <Link href="/choferes" className="text-sm text-slate-500 underline underline-offset-4">← Choferes</Link>
        <h1 className="mt-2 text-xl font-semibold">{c.nombre_completo}</h1>
        <p className="text-sm tabular-nums text-slate-500">CI {formatearCI(c.ci)}</p>
      </div>

      {c.estado_identidad !== "verificada" && (
        <div className="rounded-md border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">
          {ETIQUETA_IDENTIDAD[c.estado_identidad]}
          {padron?.encontrado && padron.nombre_completo && (
            <> · En el padrón figura como <strong>{padron.nombre_completo}</strong></>
          )}
        </div>
      )}

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader titulo="Asignación" />
          <dl className="grid grid-cols-2 gap-4 p-4">
            <Dato etiqueta="Candidato">{c.candidato ?? "—"}</Dato>
            <Dato etiqueta="Barrio">{c.barrio ?? "—"}</Dato>
            <Dato etiqueta="Supervisor">{c.supervisor ?? "—"}</Dato>
            <Dato etiqueta="Responsable">
              {c.responsable ?? "—"}
              {c.responsable_tipo && <span className="text-slate-400"> · {c.responsable_tipo}</span>}
            </Dato>
            <Dato etiqueta="Estado de servicio"><Badge>{c.estado_servicio}</Badge></Dato>
            <Dato etiqueta="Vehículo">{c.chapa ? `${c.chapa} · ${c.categoria ?? ""}` : "—"}</Dato>
          </dl>
        </Card>

        <Card>
          <CardHeader titulo="Padrón" extra={<span className="text-xs text-slate-400">consulta registrada</span>} />
          {padron?.encontrado ? (
            <dl className="grid grid-cols-2 gap-4 p-4">
              <Dato etiqueta="Local">{padron.local_nombre ?? "—"}</Dato>
              <Dato etiqueta="Mesa">{padron.mesa ?? "—"}</Dato>
              <Dato etiqueta="Orden">{padron.orden ?? "—"}</Dato>
              <Dato etiqueta="Seccional">{padron.seccional ?? "—"}</Dato>
              <div className="col-span-2"><Dato etiqueta="Dirección">{padron.direccion ?? "—"}</Dato></div>
            </dl>
          ) : (
            <Vacio mensaje="No figura en el padrón de Villa Hayes." />
          )}
        </Card>

        <Card>
          <CardHeader titulo="Contrato y caja" />
          <dl className="grid grid-cols-2 gap-4 p-4">
            <Dato etiqueta="Contrato"><Marca valor={c.contrato_firmado} si="Firmado" no="Sin firmar" /></Dato>
            <Dato etiqueta="Vale de combustible"><Marca valor={c.vale_entregado} si="Entregado" no="Sin entregar" /></Dato>
            <Dato etiqueta="Anticipo"><Marca valor={c.anticipo_pagado} si="Pagado" no="Sin pagar" /></Dato>
            <Dato etiqueta="Pago final"><Marca valor={c.pago_finalizado} si="Finalizado" no="Pendiente" /></Dato>
          </dl>
        </Card>

        <Card>
          <CardHeader titulo="Actividad y antecedentes" />
          <div className="space-y-4 p-4">
            <dl className="grid grid-cols-2 gap-4">
              <Dato etiqueta="Actividad">{c.actividad ? ETIQUETA_ACTIVIDAD[c.actividad] : "Sin datos"}</Dato>
              <Dato etiqueta="Kilómetros">{formatearKm(c.km_recorridos)}</Dato>
            </dl>
            {ants.length > 0 && (
              <div className="space-y-2 border-t border-slate-100 pt-3">
                {ants.map((a, i) => (
                  <div key={i} className="flex items-center justify-between text-sm">
                    <span>
                      <Badge tono={a.resultado === "cumplio" ? "ok" : "alerta"}>{a.resultado}</Badge>
                      <span className="ml-2 text-slate-500">{formatearKm(a.km_recorridos)}</span>
                    </span>
                    {a.confiabilidad_dato === "baja" && (
                      <span className="text-xs text-amber-700" title={a.fuente ?? ""}>
                        confiabilidad baja
                      </span>
                    )}
                  </div>
                ))}
                <p className="text-xs text-slate-400">
                  El histórico del 07/06/2026 se cruzó por nombre. Sirve para ver antecedentes,
                  no para decidir un pago.
                </p>
              </div>
            )}
          </div>
        </Card>
      </div>

      {aps.length > 1 && (
        <Card>
          <CardHeader titulo={`Esta cédula apareció ${aps.length} veces en las planillas`} />
          <ul className="divide-y divide-slate-100">
            {aps.map((a, i) => (
              <li key={i} className="flex flex-wrap items-center gap-3 px-4 py-2 text-sm">
                <Badge tono={a.fue_aplicada ? "ok" : "neutro"}>
                  {a.fue_aplicada ? "Aplicada" : "Archivada"}
                </Badge>
                <span className="text-slate-500">fila {a.numero_fila ?? "—"}</span>
                <span>{a.candidato_texto || "(sin candidato)"}</span>
                <span className="text-slate-500">· {a.barrio_texto || "(sin barrio)"}</span>
              </li>
            ))}
          </ul>
          <p className="px-4 pb-3 text-xs text-slate-400">
            Ninguna aparición se borra: quedan como evidencia de cómo figuraba en el origen.
          </p>
        </Card>
      )}
    </div>
  );
}
