import Link from "next/link";
import type { ReactNode } from "react";

const cn = (...c: (string | false | undefined)[]) => c.filter(Boolean).join(" ");

export function Card({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className={cn("rounded-lg border border-slate-200 bg-white shadow-sm", className)}>
      {children}
    </div>
  );
}

export function CardHeader({ titulo, extra }: { titulo: string; extra?: ReactNode }) {
  return (
    <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3">
      <h2 className="text-sm font-semibold text-slate-700">{titulo}</h2>
      {extra}
    </div>
  );
}

type Tono = "neutro" | "ok" | "alerta" | "error" | "info";
const TONOS: Record<Tono, string> = {
  neutro: "bg-slate-100 text-slate-700 ring-slate-200",
  ok: "bg-emerald-50 text-emerald-700 ring-emerald-200",
  alerta: "bg-amber-50 text-amber-800 ring-amber-200",
  error: "bg-rose-50 text-rose-700 ring-rose-200",
  info: "bg-sky-50 text-sky-700 ring-sky-200",
};

export function Badge({ children, tono = "neutro" }: { children: ReactNode; tono?: Tono }) {
  return (
    <span className={cn("inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ring-1 ring-inset", TONOS[tono])}>
      {children}
    </span>
  );
}

export function Boton({
  children, tipo = "primario", type = "button", ...props
}: {
  children: ReactNode; tipo?: "primario" | "secundario" | "peligro";
} & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  const estilos = {
    primario: "bg-slate-900 text-white hover:bg-slate-700",
    secundario: "bg-white text-slate-700 ring-1 ring-slate-300 hover:bg-slate-50",
    peligro: "bg-rose-600 text-white hover:bg-rose-500",
  }[tipo];
  return (
    <button type={type} {...props}
      className={cn("inline-flex items-center justify-center rounded-md px-3 py-2 text-sm font-medium transition disabled:opacity-50", estilos)}>
      {children}
    </button>
  );
}

export function Campo({
  etiqueta, nombre, requerido, ayuda, children,
}: { etiqueta: string; nombre: string; requerido?: boolean; ayuda?: string; children: ReactNode }) {
  return (
    <div className="space-y-1">
      <label htmlFor={nombre} className="block text-sm font-medium text-slate-700">
        {etiqueta}{requerido && <span className="text-rose-600"> *</span>}
      </label>
      {children}
      {ayuda && <p className="text-xs text-slate-500">{ayuda}</p>}
    </div>
  );
}

export const claseInput =
  "block w-full rounded-md border-0 px-3 py-2 text-sm text-slate-900 shadow-sm ring-1 ring-inset ring-slate-300 placeholder:text-slate-400 focus:ring-2 focus:ring-slate-900";

export function Vacio({ mensaje, accion }: { mensaje: string; accion?: ReactNode }) {
  return (
    <div className="px-4 py-12 text-center">
      <p className="text-sm text-slate-500">{mensaje}</p>
      {accion && <div className="mt-4">{accion}</div>}
    </div>
  );
}

export function Dato({ etiqueta, children }: { etiqueta: string; children: ReactNode }) {
  return (
    <div>
      <dt className="text-xs uppercase tracking-wide text-slate-500">{etiqueta}</dt>
      <dd className="mt-0.5 text-sm text-slate-900">{children}</dd>
    </div>
  );
}

export function Enlace({ href, children }: { href: string; children: ReactNode }) {
  return <Link href={href} className="text-sm font-medium text-slate-900 underline underline-offset-4 hover:text-slate-600">{children}</Link>;
}
