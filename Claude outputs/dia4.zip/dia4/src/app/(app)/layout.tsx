import Link from "next/link";
import { redirect } from "next/navigation";
import { crearClienteServidor } from "@/lib/supabase/server";

const NAV = [
  { href: "/", texto: "Tablero" },
  { href: "/choferes", texto: "Choferes" },
  { href: "/caja", texto: "Caja" },
  { href: "/folios", texto: "Folios" },
  { href: "/lista-negra", texto: "Lista negra" },
  { href: "/cupos", texto: "Cupos" },
];

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const supabase = await crearClienteServidor();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: perfil } = await supabase
    .from("usuarios").select("nombre_completo").eq("id", user.id).maybeSingle();

  async function salir() {
    "use server";
    const s = await crearClienteServidor();
    await s.auth.signOut();
    redirect("/login");
  }

  return (
    <div className="min-h-screen">
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-6">
            <span className="text-sm font-semibold">Logística Día D</span>
            <nav className="flex gap-4">
              {NAV.map((n) => (
                <Link key={n.href} href={n.href}
                  className="text-sm text-slate-600 hover:text-slate-900">{n.texto}</Link>
              ))}
            </nav>
          </div>
          <form action={salir} className="flex items-center gap-3">
            <span className="hidden text-sm text-slate-500 sm:inline">
              {perfil?.nombre_completo ?? user.email}
            </span>
            <button className="text-sm text-slate-600 underline underline-offset-4 hover:text-slate-900">
              Salir
            </button>
          </form>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-4 py-6">{children}</main>
    </div>
  );
}
